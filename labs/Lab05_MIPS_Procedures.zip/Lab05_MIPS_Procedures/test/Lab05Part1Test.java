/*
 * MIPSUnit::MUnit is a JUnit-based unit testing framework for MIPS assembly created by
 * and freely distributed by Zachary Kurmas.  More information can be found at:
 * http://www.cis.gvsu.edu/~kurmasz/Software/mipsunit_munit/
 */

import org.junit.*;
import static org.junit.Assert.*;

import static edu.gvsu.mipsunit.munit.MUnit.Register.*;
import static edu.gvsu.mipsunit.munit.MUnit.*;

public class Lab05Part1Test {

    //////////////////////////////////////////////////////////////////////////////////////////
    // Multiply Tests
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 100
    public void verify_multiply_0() {
        set(v0, 9999);  // set some dummy value to ensure that it gets overwritten
        run("multiply", 0, 0);
        assertEquals("\n\tWhen multiplying '0 * 0', final value should be 0 -- ", 0, get(v0));
    }
    
    @Test(timeout=1000)  // 101
    public void verify_multiply_1() {
        set(v0, 9999);  // set some dummy value to ensure that it gets overwritten
        run("multiply", 10, 0);
        assertEquals("\n\tWhen multiplying '10 * 0', final value should be 0 -- ", 0, get(v0));
    }
    
    @Test(timeout=1000)  // 102
    public void verify_multiply_2() {
        set(v0, 9999);  // set some dummy value to ensure that it gets overwritten
        run("multiply", 10, 15);
        assertEquals("\n\tWhen multiplying '10 * 15', final value should be 0 -- ", 150, get(v0));
    }
    
    @Test(timeout=1000)  // 103
    public void verify_multiply_3() {
        set(v0, 9999);  // set some dummy value to ensure that it gets overwritten
        run("multiply", 131071, 16384);
        assertEquals("\n\tWhen multiplying '131071 * 16384', final value should be 2147467264 -- ", 2147467264, get(v0));
    }
    
    @Test(timeout=1000)  // 104
    public void verify_stack_pointer_after_calling_multiply() {
        run("multiply", 6, 6);
        assertEquals("\n\tAfter calling \"multiply\" procedure stack pointer should be 0x7FFFEFFC -- ", 0x7FFFEFFC, get(sp));
    }
    //////////////////////////////////////////////////////////////////////////////////////////



    //////////////////////////////////////////////////////////////////////////////////////////
    // Divide Tests
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 105
    public void verify_divide_0() {
        set(v0, 9999);  // set some dummy value to ensure that it gets overwritten
        run("divide", 0, 10);
        assertEquals("\n\tWhen dividing '0 / 10', final value should be 0 -- ", 0, get(v0));
    }
    
    @Test(timeout=1000)  // 106
    public void verify_divide_1() {
        set(v0, 9999);  // set some dummy value to ensure that it gets overwritten
        run("divide", 10, 10);
        assertEquals("\n\tWhen dividing '10 / 10', final value should be 1 -- ", 1, get(v0));
    }
    
    @Test(timeout=1000)  // 107
    public void verify_divide_2() {
        set(v0, 9999);  // set some dummy value to ensure that it gets overwritten
        run("divide", 10, 3);
        assertEquals("\n\tWhen dividing '10 / 3', final value should be 3 -- ", 3, get(v0));
    }
    
    @Test(timeout=1000)  // 108
    public void verify_divide_3() {
        set(v0, 9999);  // set some dummy value to ensure that it gets overwritten
        run("divide", 131071, 16384);
        assertEquals("\n\tWhen dividing '131071 / 16384', final value should be 7 -- ", 7, get(v0));
    }
    
    @Test(timeout=1000)  // 109
    public void verify_stack_pointer_after_calling_divide() {
        run("divide", 6, 6);
        assertEquals("\n\tAfter calling \"divide\" procedure stack pointer should be 0x7FFFEFFC -- ", 0x7FFFEFFC, get(sp));
    }
    //////////////////////////////////////////////////////////////////////////////////////////



    //////////////////////////////////////////////////////////////////////////////////////////
    // Equation Tests
    //////////////////////////////////////////////////////////////////////////////////////////
    @Test(timeout=1000)  // 110
    public void verify_complete_eq_computation_0() {
        set(s0, 3);
        set(s1, 4);
        set(s2, 5);
        set(s3, 9999);  // set some dummy value to ensure that it gets overwritten
        run("ece260_main");
        assertEquals("\n\tWhen X=3, Y=4, and Z=5, value of F should be 0 and stored in register $s3 -- ", 0, get(s3)); 
    }
    
    @Test(timeout=1000)  // 111
    public void verify_complete_eq_computation_1() {
        set(s0, 15);
        set(s1, 4);
        set(s2, 5);
        set(s3, 9999);  // set some dummy value to ensure that it gets overwritten
        run("ece260_main");
        assertEquals("\n\tWhen X=15, Y=4, and Z=5, value of F should be 2 and stored in register $s3 -- ", 2, get(s3)); 
    }
    
    @Test(timeout=1000)  // 112
    public void verify_complete_eq_computation_2() {
        set(s0, 100);
        set(s1, 5);
        set(s2, 3);
        set(s3, 9999);  // set some dummy value to ensure that it gets overwritten
        run("ece260_main");
        assertEquals("\n\tWhen X=100, Y=5, and Z=3, value of F should be 20 and stored in register $s3 -- ", 20, get(s3)); 
    }
    
    @Test(timeout=1000)  // 113
    public void verify_stack_pointer_after_computing_equation() {
        set(s0, 100);
        set(s1, 5);
        set(s2, 3);
        set(s3, 9999);  // set some dummy value to ensure that it gets overwritten
        run("ece260_main");
        assertEquals("\n\tAfter terminating stack pointer should be 0x7FFFEFFC -- ", 0x7FFFEFFC, get(sp));
    }
    //////////////////////////////////////////////////////////////////////////////////////////
}
